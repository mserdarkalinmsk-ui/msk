// Additive components for the uploaded standalone Portfolio Ledger build.
function premiumEvidence(project) {
  const reports = (project.reportingPeriods || []).filter(r => r.snapshot?.lines?.some(l => l.actual != null) && Number.isFinite(Date.parse(r.date)) && Date.parse(r.date) <= I.getTime()).sort((a,b) => Date.parse(a.date)-Date.parse(b.date));
  const latest = reports.at(-1);
  const fresh = latest && I.getTime()-Date.parse(latest.date) <= 180*86400000;
  const distinct = new Set(reports.map(r=>r.date)).size;
  return {reports, latest, fresh, forecast: !project.datesTbc && distinct >= 2 && fresh};
}
function premiumForecastReady(projects) {return projects.length > 0 && projects.every(p=>premiumEvidence(p).forecast);}
function PremiumEvidence({projects}) {
  const evidence = projects.map(p=>({p,...premiumEvidence(p)}));
  const covered = evidence.filter(x=>x.latest).length;
  const fresh = evidence.filter(x=>x.fresh).length;
  const ready = premiumForecastReady(projects);
  return e('section',{class:'card premium-evidence','aria-label':'Evidence and forecast readiness',children:[
    e('div',{class:'card-h',children:e('div',{children:[e('h2',{children:'Evidence before decisions'}),e('p',{children:`${covered}/${projects.length} projects have dated financial snapshots · ${fresh}/${projects.length} updated within 180 days`})]})}),
    e('div',{class:'card-b',children:[
      e('p',{class:'premium-note',children:ready?'Forecast enabled: every selected project has at least two dated actual-spend snapshots and a report within 180 days. The ±20% range is a scenario assumption, not a confidence interval.':'Forecast withheld: every selected project needs at least two dated actual-spend snapshots and a report within 180 days. Missing reports do not establish zero expenditure.'}),
      e('p',{class:'muted',children:'Financial pace compares spending with elapsed time; it does not measure delivery. Totals below are recorded application values; incomplete evidence requires review.'}),
      e('details',{children:[e('summary',{children:'Review sources by project'}),e('div',{class:'premium-source-list',children:evidence.map(x=>e('div',{class:'premium-source',key:x.p.id,children:[e('button',{class:'btn ghost',onClick:()=>Y({drawer:{kind:'project',id:x.p.id}}),children:x.p.code||x.p.name}),e('span',{children:x.latest?`Latest snapshot: ${x.latest.date} · ${x.reports.length} reports · ${x.fresh?'within freshness window':'older than 180 days'}`:'No dated actual-spend snapshot'}),e('span',{class:'badge',children:x.forecast?'Forecast eligible':'Review evidence'})]}))})]})
    ]})
  ]});
}
function PremiumWeek({projects}) {
  const today=un(I), until=new Date(I); until.setUTCDate(until.getUTCDate()+7);
  const events=hr(projects), overdue=events.filter(x=>x.day<today&&x.tone==='bad'&&x.kind!=='activity'), upcoming=events.filter(x=>x.day>=today&&x.day<=un(until));
  return e('details',{class:'card premium-week',children:[e('summary',{children:`This week · ${overdue.length} overdue reports / milestones · ${upcoming.length} upcoming`}),e('div',{class:'card-b',children:[e('p',{class:'muted',children:`${q(today)} – ${q(un(until))} · selected portfolio`}),...overdue.slice(0,5).map(x=>e('button',{class:'premium-event',onClick:()=>he(`project/${x.p.id}`),children:`Overdue · ${x.p.code}${x.p.bh?' · BH '+x.p.bh:''} · ${x.title} · ${q(x.day)}`})),e('button',{class:'btn',onClick:()=>he('reports/calendar'),children:'Open full calendar'})]})]});
}
const premiumFollowKey='pl-premium-followups-v1';
function premiumReadFollowups(){try{const data=JSON.parse(localStorage.getItem(premiumFollowKey)||'{}');return data&&typeof data==='object'&&!Array.isArray(data)?data:{};}catch{return {};}}
function premiumAlertKey(alert){return JSON.stringify([alert.projectId,alert.kind,alert.title,alert.detail]);}
function PremiumFollow({alert}) {
  const key=premiumAlertKey(alert);
  const [saved,setSaved]=N(()=>premiumReadFollowups()[key]||{});
  const [message,setMessage]=N('');
  return e('details',{class:'premium-follow',onClick:event=>event.stopPropagation(),onKeyDown:event=>event.stopPropagation(),children:[
    e('summary',{children:saved.status?`Follow-up · ${saved.status}${saved.owner?' · '+saved.owner:''}`:'Record follow-up'}),
    e('form',{onSubmit:event=>{event.preventDefault();const form=new FormData(event.currentTarget);const entry={owner:String(form.get('owner')||''),due:String(form.get('due')||''),status:String(form.get('status')||'Open'),notes:String(form.get('notes')||''),updatedAt:new Date().toISOString(),projectId:alert.projectId,title:alert.title,detail:alert.detail};try{const all=premiumReadFollowups();all[key]=entry;localStorage.setItem(premiumFollowKey,JSON.stringify(all));setSaved(entry);setMessage('Saved in this browser. The source condition remains visible.');}catch{setMessage('Could not save. Browser storage may be unavailable or full.');}},children:[
      e('label',{children:['Owner',e('input',{name:'owner',maxLength:160,defaultValue:saved.owner||''})]}),
      e('label',{children:['Follow-up date',e('input',{name:'due',type:'date',defaultValue:saved.due||''})]}),
      e('label',{children:['Review state',e('select',{name:'status',defaultValue:saved.status||'Open',children:['Open','In review','Resolution recorded'].map(value=>e('option',{value,children:value}))})]}),
      e('label',{children:['Notes',e('textarea',{name:'notes',maxLength:4000,defaultValue:saved.notes||''})]}),
      e('button',{class:'btn primary',type:'submit',children:'Save follow-up'}),
      e('p',{class:'muted',children:'Stored separately on this browser/origin. Export follow-ups below to keep a portable copy. Changed source details create a new follow-up.'}),
      e('p',{role:'status',children:message})
    ]})
  ]});
}
function PremiumBackup(){
  const [message,setMessage]=N('');
  return e('details',{class:'card premium-week',children:[e('summary',{children:'Follow-up backup · separate from portfolio backup'}),e('div',{class:'card-b',children:[
    e('button',{class:'btn',onClick:()=>{const blob=new Blob([JSON.stringify({format:'portfolio-followups-v1',entries:premiumReadFollowups()},null,2)],{type:'application/json'});$n('portfolio-followups.json',blob);},children:'Export follow-ups'}),
    e('label',{class:'premium-import',children:['Restore follow-ups (adds missing entries only)',e('input',{type:'file',accept:'.json,application/json',onChange:async event=>{try{const file=event.target.files[0];if(!file)return;if(file.size>2000000)throw Error('Backup exceeds 2 MB');const data=JSON.parse(await file.text());if(data.format!=='portfolio-followups-v1'||!data.entries||typeof data.entries!=='object'||Array.isArray(data.entries))throw Error('Unsupported backup');const all=premiumReadFollowups();let count=0;for(const [key,value] of Object.entries(data.entries)){if(!value||typeof value!=='object'||!['Open','In review','Resolution recorded'].includes(value.status)||!['owner','due','notes','projectId','title','detail','updatedAt'].every(field=>typeof value[field]==='string'))throw Error('Invalid follow-up entry');if(!Object.hasOwn(all,key)){Object.defineProperty(all,key,{value,enumerable:true,writable:true,configurable:true});count++;}}localStorage.setItem(premiumFollowKey,JSON.stringify(all));setMessage(`${count} entries restored. Reopen Overview to refresh follow-up labels.`);}catch(error){setMessage('Restore failed: '+error.message);}}})]}),
    e('p',{role:'status',children:message})
  ]})]});
}
