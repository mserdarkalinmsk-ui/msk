from pathlib import Path
ROOT=Path(__file__).resolve().parent
s=(ROOT/'original.html').read_text()
def replace_once(old,new):
    global s
    assert s.count(old)==1, (old[:90],s.count(old))
    s=s.replace(old,new,1)
replace_once('function ud(){', (ROOT/'premium.js').read_text()+'\nfunction ud(){')
replace_once('i=pr(n,I),o=en(n,I)', 'i=pr(n,I).map(point=>premiumForecastReady(n)?point:{...point,low:null,mid:null,high:null}),o=en(n,I)')
replace_once('y.funding??"";return n.length?e(U,{children:[e(yn,{}),e("section",{class:"hero"', 'y.funding??"";return n.length?e(U,{children:[e(yn,{}),e(PremiumWeek,{projects:n}),e(PremiumEvidence,{projects:n}),e("section",{class:"hero"')
replace_once('h?.mid!=null?e(U,', 'premiumForecastReady(n)&&h?.mid!=null?e(U,')
replace_once('}):"no forecast"', '}):"Forecast withheld — review evidence above"')
replace_once('children:"spend share minus time share"','children:"Financial pace only · not delivery progress"')
replace_once('children:pd(c)', 'children:n.every(project=>premiumEvidence(project).fresh)?pd(c):"Evidence incomplete"')
replace_once('children:e(Zn,{value:c,format:Ve})', 'children:n.every(project=>premiumEvidence(project).fresh)?e(Zn,{value:c,format:Ve}):"—"')
replace_once('"Cumulative actual spend, linear plan and forecast range (recent burn rate ±20%)"','(premiumForecastReady(n)?"Cumulative actual spend, linear plan and forecast scenario (±20%, not a confidence interval)":"Recorded actual spend and linear plan · forecast withheld pending evidence")')
replace_once('"Forecast range"]', '(premiumForecastReady(n)?"Forecast scenario range":"Forecast unavailable")]')
# Do not interpret missing or stale evidence as a spending-pace warning.
replace_once('c>.1&&l<-.15&&r.push', 'premiumEvidence(i).fresh&&c>.1&&l<-.15&&r.push')
replace_once('l>.1&&r.push({projectId:i.id,kind:"overspend"', 'premiumEvidence(i).fresh&&l>.1&&r.push({projectId:i.id,kind:"overspend"')
replace_once('children:y.detail})]}),e("span",{class:"code",children:L.code})', 'children:y.detail}),e(PremiumFollow,{key:premiumAlertKey(y),alert:y})]}),e("span",{class:"code",children:L.code})')
replace_once('e(hd,{}),e(Ha,{variant:"card"})', 'e(PremiumBackup,{}),e(hd,{}),e(Ha,{variant:"card"})')
# Suppress the automatic digest, now available as an inline selected-scope summary.
start=s.index('function qd(){');end=s.index('const ji=',start)
s=s[:start]+'function qd(){return null;}'+s[end:]
replace_once('</head>\n<body>', '<style>\n'+(ROOT/'premium.css').read_text()+'\n</style></head>\n<body>')
(ROOT/'portfolio-analysis-premium.html').write_text(s)
print('Built portfolio-analysis-premium.html')
